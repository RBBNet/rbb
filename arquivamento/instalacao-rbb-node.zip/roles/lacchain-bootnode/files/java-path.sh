export JAVAPATH=$HOME/java
export PATH=$JAVAPATH/bin:$PATH