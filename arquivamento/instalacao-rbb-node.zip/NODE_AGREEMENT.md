# REGISTRATION AGREEMENT FOR NODE DEPLOYMENT

We understand that this is an agreement form required for the deployment of nodes in the LACChain Blockchain Networks at Test-Net stages.

The entity accountable for the deployment of the nodes will be ___NAME_OF_THE_ENTITY_____ residing at _____ADDRESS_____. The technical person responsible for the administration of the nodes will be __NAME____ reachable at the e-mail address ____E-MAIL_ADDRESS_____ and at the phone number ____PHONE_NUMER_INCLUDING_COUNTRY_CODE____. The point of contact from your organization for communications of general purpose related to LACChain will be __NAME____ reachable at the e-mail address ____E-MAIL_ADDRESS_____ and at the phone number ___PHONE_NUMER_INCLUDING_COUNTRY_CODE____. 

We hereby declare that we have read and agree with the [Terms and Conditions for LACChain Test Networks for Writer Nodes](https://github.com/lacchain/pantheon-network/blob/master/TERMS_AND_COND_WRITER_NODE.md), and the [Terms and Conditions for LACChain Test Networks for Validator Nodes](https://github.com/lacchain/pantheon-network/blob/master/TERMS_AND_COND_VAL_NODE.md).  

Signature:

Name:

Date:

Place:
